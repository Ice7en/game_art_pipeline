"""
Flask Web UI for Game + Art Multi-Agent Pipeline
Run: python web_ui/app.py
"""

import sys
import os
import json
import threading
import time
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

app = Flask(__name__)
app.config["SECRET_KEY"] = "game-art-pipeline-secret"

# Global state for tracking pipeline runs
pipeline_state = {
    "running": False,
    "logs": [],
    "current_step": 0,
    "total_steps": 5,
    "result": None,
    "error": None,
}

STEPS = [
    ("worldbuilding", "🌍 世界观生成", "WorldbuildingAgent"),
    ("character", "🎨 角色设计", "CharacterAgent"),
    ("code", "💻 游戏代码", "CodeAgent"),
    ("poster", "🖼️  宣传海报", "PosterAgent"),
    ("publisher", "📦 发行文案", "PublisherAgent"),
]


def run_pipeline_thread(theme: str, output_dir: str):
    """Run pipeline in background thread."""
    global pipeline_state
    pipeline_state["running"] = True
    pipeline_state["logs"] = []
    pipeline_state["current_step"] = 0
    pipeline_state["result"] = None
    pipeline_state["error"] = None

    try:
        from orchestrator import GameArtOrchestrator

        orchestrator = GameArtOrchestrator(output_dir=output_dir)

        def log_callback(message: str, level: str):
            pipeline_state["logs"].append({"message": message, "level": level, "time": time.strftime("%H:%M:%S")})
            # Update current step based on message
            for i, (step_id, step_name, _) in enumerate(STEPS):
                if step_name.split(" ", 1)[1] in message or str(i + 1) + "/5" in message:
                    pipeline_state["current_step"] = i + 1

        orchestrator.log_callback = log_callback

        result = orchestrator.run(theme_keywords=theme)
        pipeline_state["result"] = result
        pipeline_state["current_step"] = 5

    except Exception as e:
        pipeline_state["error"] = str(e)
        import traceback
        pipeline_state["logs"].append({
            "message": f"❌ 错误: {traceback.format_exc()}",
            "level": "error",
            "time": time.strftime("%H:%M:%S")
        })
    finally:
        pipeline_state["running"] = False


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/start", methods=["POST"])
def start_pipeline():
    global pipeline_state
    if pipeline_state["running"]:
        return jsonify({"error": "Pipeline 正在运行中"}), 400

    data = request.json
    theme = data.get("theme", "").strip()
    if not theme:
        return jsonify({"error": "请输入主题关键词"}), 400

    output_dir = f"output_{int(time.time())}"
    os.makedirs(output_dir, exist_ok=True)

    thread = threading.Thread(
        target=run_pipeline_thread,
        args=(theme, output_dir),
        daemon=True
    )
    thread.start()

    return jsonify({"status": "started", "output_dir": output_dir})


@app.route("/api/status")
def get_status():
    return jsonify({
        "running": pipeline_state["running"],
        "logs": pipeline_state["logs"][-50:],  # Last 50 logs
        "current_step": pipeline_state["current_step"],
        "total_steps": pipeline_state["total_steps"],
        "result": pipeline_state["result"],
        "error": pipeline_state["error"],
    })


@app.route("/api/file")
def get_file():
    """Serve generated files."""
    path = request.args.get("path", "")
    if not path or ".." in path:
        return "Invalid path", 400
    
    file_path = Path(path)
    if not file_path.exists():
        return "File not found", 404
    
    return send_from_directory(str(file_path.parent), file_path.name)


@app.route("/api/preview")
def preview_file():
    """Return file content for preview."""
    path = request.args.get("path", "")
    if not path or ".." in path:
        return jsonify({"error": "Invalid path"}), 400
    
    file_path = Path(path)
    if not file_path.exists():
        return jsonify({"error": "File not found"}), 404
    
    suffix = file_path.suffix.lower()
    if suffix == ".json":
        with open(file_path, encoding="utf-8") as f:
            return jsonify(json.load(f))
    elif suffix == ".html":
        with open(file_path, encoding="utf-8") as f:
            return f.read(), 200, {"Content-Type": "text/html"}
    
    return jsonify({"error": "Unsupported file type"}), 400


if __name__ == "__main__":
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("⚠️  警告: 未设置 ANTHROPIC_API_KEY 环境变量")
        print("   export ANTHROPIC_API_KEY='your-api-key-here'")
    
    print("🚀 启动 Web UI: http://localhost:5000")
    app.run(debug=True, host="0.0.0.0", port=5000)
